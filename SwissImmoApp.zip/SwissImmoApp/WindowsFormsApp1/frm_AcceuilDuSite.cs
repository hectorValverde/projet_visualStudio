﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Ceci va ouvrir la fenetre de connexion au milieu de l'écran
            frm_FenetreDeConnexion win2 = new frm_FenetreDeConnexion();
            win2.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'dataSet1.VW_BIENS'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.vW_BIENSTableAdapter.Fill(this.dataSet1.VW_BIENS);

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btn_trouver_logement_Click(object sender, EventArgs e)
        {
            frm_Recherche_bail search = new frm_Recherche_bail();
            search.Show();
        }

        private void btn_espace_admin_Click(object sender, EventArgs e)
        {
            frm_FenetreDeConnexion win2 = new frm_FenetreDeConnexion();
            win2.Show();
        }
        public void showBtnAdmin() {
            btn_espace_admin.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.google.com/maps/place/Gen%C3%A8ve/@46.2050242,6.1090692,13z/data=!3m1!4b1!4m5!3m4!1s0x478c650693d0e2eb:0xa0b695357b0bbc39!8m2!3d46.2043907!4d6.1431577");
        }
    }
}
