﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frm_FenetreDeConnexion : Form
    {
        public frm_FenetreDeConnexion()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_CreationDeCompte create = new frm_CreationDeCompte();
            create.Show();
        }

        private void btn_mdp_oublie_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Un email avec des instructions \nvous a été envoyé .", "Réinitialitez votre mot de passe", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!txt_email.Text.Contains("@"))
            {
                MessageBox.Show("Adresse mail invalide.", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (txt_email.Text == "admin@admin.ch" && txt_mdp.Text == "admin") {
                this.Hide();
                frm_espace_admin admin = new frm_espace_admin();
                admin.Show();
            }
            else { MessageBox.Show("Email ou mot de passe incorrect.", "Erreur de saisie", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning); }
        }

        private void btn_identifier_Click(object sender, EventArgs e)
        {

        }
    }
}
