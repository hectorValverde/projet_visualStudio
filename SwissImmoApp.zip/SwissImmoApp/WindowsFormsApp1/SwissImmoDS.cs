﻿namespace WindowsFormsApp1
{


    partial class SwissImmoDS
    {
    }
}

namespace WindowsFormsApp1.SwissImmoDSTableAdapters {
    
    
    public partial class SI_PERSONNETableAdapter {
    }
}
