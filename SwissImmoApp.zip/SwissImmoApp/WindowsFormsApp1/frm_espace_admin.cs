﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace WindowsFormsApp1
{
    public partial class frm_espace_admin : Form
    {
        public ArrayList users = new ArrayList();

        public frm_espace_admin()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //Cette méathode va tout simplement créer une ligne avec les éléments saisis et l'ajouter dans la ListView des utilisateurs
        public void addUser(string civ, string nom, string prenom, string email, string telephone) {

            ListViewItem ligne = new ListViewItem();
            ligne.Text = civ;
            ligne.SubItems.Add(nom);
            ligne.SubItems.Add(prenom);
            ligne.SubItems.Add(email);
            ligne.SubItems.Add(telephone);

            this.users.Add(ligne);


            //lvw_liste_users.Items.Add(ligne); Ceci était un tableau qui affichait les clients (vide avant l'insertion de la BDD)
        }


        /*
         Cette méthode a pour objectif d'ajouter un élément à la liste d'utilisateurs manuellement par l'administrateur
        - Premièrement : il faut controler si l'adresse mail correspond à notre liste d'utilisateurs
        - Deuxièmement : il faut contrôler que le numéro de téléphone ne contiennent une valeur de type Integer
        - Troisièmement : on fait appel à la méthode addUser qui va récupérer les valeurs founies par l'utilisateur et les ajouter dans les colonnes indiquées
        - Finalement : un petit message est affiché pour indiquer qu'une ligne a bien été saisie
         */
        private void btn_insertion_Click(object sender, EventArgs e)
        {
            //déclaration des variables pour l'insertion d'une personne
            //Le Id sera changé et attribué automatiquement 
            int id = 666;
            String nom = txt_nom.Text;
            String prenom = txt_prenom.Text;
            String email = txt_email.Text;
            int telephone = int.Parse(txt_telephone.Text);



            int n;
            bool isNumeric = int.TryParse(txt_telephone.Text, out n);
            if (!txt_email.Text.Contains("@"))
            {
                MessageBox.Show("Adresse mail invalide.", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!isNumeric)
            {
                MessageBox.Show("Numéro de téléphone invalide.", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Cette partie du code se charge d'ajouter un nouvel utilisateur à la BDD. 
            else
            {
                SwissImmoDSTableAdapters.SI_PERSONNETableAdapter ajout = new SwissImmoDSTableAdapters.SI_PERSONNETableAdapter();
                ajout.InsertQueryPersonne(id, nom, prenom, email, telephone);
              
                lbl_message.Text = "Utilisateur ajouté avec succès";
            }
        }

        //Cette méthode va supprimer la selection dans notre ListView
        private void btn_supprimer_Click(object sender, EventArgs e)
        {
            
            String selected_nom = dataGridViewTextBoxColumnNom.ToString();
            String selected_prenom = dataGridViewTextBoxColumnNom.ToString();
            String selected_mail = dataGridViewTextBoxColumnEmail.ToString();
            //int selected_telephone = int.Parse(dataGridViewTextBoxColumnTelephone.ToString());

          
            SwissImmoDSTableAdapters.SI_PERSONNETableAdapter del = new SwissImmoDSTableAdapters.SI_PERSONNETableAdapter();
            del.DeleteQuery(1, selected_nom, 1, selected_prenom, 1, selected_mail);


            //lvw_liste_users.Items.Remove(lvw_liste_users.SelectedItems[0]); Ceci était un tableau qui affichait les clients (vide avant l'insertion de la BDD)

            //Idéalement la couleur devrait être rouge mais ca ne l'est pas... surement dû au fait que le label est en mode "Enable : False"



            lbl_message.ForeColor = Color.Red;
            lbl_message.Text = "Utilisateur supprimé avec succès.";
        }


        //Cette méthode va ajouter un nouvel élément à la liste Array des users.
        public void ajout_user(ListViewItem user ) {
            this.users.Add(user);
        }

        private void frm_espace_admin_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'swissImmoDS.VW_BIENS'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.vW_BIENSTableAdapter.Fill(this.swissImmoDS.VW_BIENS);
            // TODO: cette ligne de code charge les données dans la table 'swissImmoDS.VW_UTILISATEURS'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.vW_UTILISATEURSTableAdapter1.Fill(this.swissImmoDS.VW_UTILISATEURS);
            // TODO: cette ligne de code charge les données dans la table 'dataSet1.VW_UTILISATEURS'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.vW_UTILISATEURSTableAdapter.Fill(this.dataSet1.VW_UTILISATEURS);

        }

        private void vW_UTILISATEURSDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void vW_UTILISATEURSDataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void vW_UTILISATEURSDataGridView_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void vW_UTILISATEURSDataGridView_CellContentClick_3(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void vW_UTILISATEURSDataGridView_CellContentClick_4(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
